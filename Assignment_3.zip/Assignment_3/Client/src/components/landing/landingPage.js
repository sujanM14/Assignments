import React from "react";

function Landing() {
    // Inline styles for buttons
    const buttonStyle = {
        backgroundColor: "#1a56d9",
        color: "white",
        borderRadius: "5px",
        padding: "10px 20px",
        marginRight: "10px",
        border: "none",
        cursor: "pointer"
    };

    // Inline styles for container div
    const containerStyle = {
        textAlign: "center",
        padding: "25px",
        backgroundColor: "#f4f4f4"
    };

    // Inline styles for heading
    const headingStyle = {
        fontSize: "2.5rem",
        marginBottom: "30px"
    };

    // Inline styles for image container
    const imageContainerStyle = {
        maxWidth: "100%",
        height: "auto",
        marginBottom: "20px"
    };

    return (
        <div>
            {/* Main content */}
            <div style={containerStyle}>
                <h1 style={headingStyle}>Welcome to Walchand College Of Engineering</h1>
                <div style={{marginBottom:"20px"}}>
                    <button style={buttonStyle}><a href="/studentLogin"> Student login</a></button>
                    <button style={buttonStyle}><a href="/instructorLogin"> Instructor login</a></button>
                </div>
                <div style={imageContainerStyle}>
                    <img
                        src="https://upload.wikimedia.org/wikipedia/commons/4/49/WCE_Sangli.jpg"
                        alt="WCE"
                    />
                </div>
                <p>
                    Walchand College Of Engineering is a college in Sangli established in 1947 with a campus of 90 acres. It is one of the best colleges of Maharashtra having a very good placement stats.
                </p>
            </div>
        </div>
    );
}

export default Landing;
