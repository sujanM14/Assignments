import React, { useState } from 'react';
import Timer from './comp/Timer';
import Student from './comp/Student';
import InCharge from './comp/InCharge';
import './App.css'
// import Questions from './comp/Questions';;

const App = () => {
  const [testStarted, setTestStarted] = useState(false);
  const [stu, sets] = useState(false);
  const [inch, seti] = useState(false);
  const [tim, sett] = useState(0);
  // const [que,setque]=useState(0);
  const[id,setid]=useState(0)

function settime (t)
{
  sett(t);
  alert("time set to : "+t+"s")
};
  function startTest  (id)  {
setid(id);  
console.log(id+"finally");
setTestStarted(true);
  };

  const handleTimeout = () => {
    setTestStarted(false);
    // Additional logic to handle test completion
  };
function st()
{
sets(true)
seti(false)
}
function inc()
{
  seti(true)
  sets(false)
}
  return (
    <div className='outer'>
<h1> Chhtrapati Shahu College of Engineering, Kolhapur</h1>

    <button onClick={st} >student</button>
    <button onClick={inc}>in-charge</button>
       
       {testStarted===true  &&(
        <Timer onTimeout={handleTimeout} tim={tim} id={id}/>
      )}
      
          {testStarted===false && (
          <div>
         { inch===true&&( <InCharge settime={settime}> </InCharge>)} 
         {stu===true&&( <Student startTest={startTest}  />)}
      
          </div>)}
      
     
    </div>
  );
};

export default App;
