import React, { useState } from 'react';
import axios from 'axios';
import './InCharge.css'

const InCharge = ({settime}) => {
    const [formData, setFormData] = useState({
        id: '',
        password: '',
      });
    const[stt,setstt]=useState(false)
      const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
       
       
        try {
          // Send a POST request to your server endpoint
          const response = await axios.post('http://localhost:5000/stud', formData);
    
          if (response.data.success) {
            setstt(true);
            alert(`Welcome!!!`);
           
          } else {
            setstt(false);
            alert('Invalid ID or password');
          }
        } catch (error) {
          console.error('Error submitting data:', error);
          alert('Error submitting data. Please try again.');
        }
         
        } 
const[time,set]=useState()
function tim(e)
{
    set(e.target.value);

}
function now()
{
    settime(time)
}

  return (
    <div>
      <h2>In-Charge Component</h2>
 
      <label>ID:</label>
      <input type='number' onChange={handleChange} name="id"></input>
      <label>password:</label>
      <input type='text' onChange={handleChange} name='password'></input>
      <button onClick={handleSubmit}>submit</button>
     
     {stt===true&&(<div> <label>test time:</label>
      <input type='number' onChange={tim}></input>
      <button onClick={now}>submit</button></div>)}
    </div>
  );
};

export default InCharge;
