import React, { useState, useEffect } from 'react';
import Questions from './Questions';;

const Timer = ({ onTimeout, tim,id }) => {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds((prevSeconds) => prevSeconds + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (seconds === tim) {
      clearInterval(Timer); // Use the correct variable 'timer' here
      onTimeout();
    }
  }, [seconds, onTimeout, tim]);

  return (
    <div>
      {/* <p>{id}</p> */}
      <p>Time Left:  {Math.max(tim - seconds, 0)}  seconds</p>
     {Math.max(tim - seconds, 0)>0 && <Questions aid={id}></Questions>}
    </div>
  );
};

export default Timer;
