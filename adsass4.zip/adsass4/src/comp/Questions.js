import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Questions = ({aid}) => {
  const [vis,setvis]=useState(0);
  const [questions, setQuestions] = useState([]);
const [obj,setarr]=useState({id:'',arr:[]});
  useEffect(() => {
    // Fetch questions from the server when the component mounts
    fetchQuestions();
  }, []);
  function sele(index,o,aid){
const cop=[...obj.arr];
cop[index]=o;
console.log(aid);
setarr( {id: aid , arr: cop});
// console.log(index +"dd" +o);
  }

  const sub= async (e) => {
    e.preventDefault();
       
       
    try {
      // Send a POST request to your server endpoint
      const response = await axios.post('http://localhost:5000/quesub', obj);

      if (response.data.success) {
        alert(`submitted successfully!!`);
       
      } else {
        alert(' submitted successfully!!!!!');//changed
      }
    } catch (error) {
      console.error('Error submitting data:', error);
      alert('Error submitting data. Please try again.');
    }
    setvis(1);
  }
  
  const fetchQuestions = async () => {
    try {
      const response = await axios.get('http://localhost:5000/questions');
      // console.log("jay");
      console.log(response.data);
      setQuestions(response.data);
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  return (
    <div>
      <h2>Questions</h2>
      <p>{aid}</p>
      <ul>
     {questions.map((question, index) => (
          <li key={index}>
           {  vis===0 &&(  
           <div><p>{question.que}</p>
            <ul>
              {/* <button type='radio' onClick={sele}></button> */}
                <input type='radio' onChange={()=>{sele(index,1,aid)}} name="group2"  ></input>{question.o1} 
               <input type='radio' onChange={()=>{sele(index,2,aid)}} name="group2" ></input>  {question.o2}
                 <input type='radio' onChange={()=>{sele(index,3,aid)}} name="group2"></input>{question.o3} 
               <input type='radio' onChange={()=>{sele(index,4,aid)}} name="group2" ></input> {question.o4}  
            </ul>
            </div>
           )}
          </li>
        ))}
         {  vis===0 &&(<button onClick={sub}>submit</button>)}
      </ul>
  
    </div>
  );
};

export default Questions;
