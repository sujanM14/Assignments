import React, { useState } from 'react';
import axios from 'axios';
// import Questions from './Questions';;
import './InCharge.css'


const Student = ({ startTest }) => {
    const [formData, setFormData] = useState({
        id: '',
        password: '',
      });
    const[stt,setstt]=useState(false)
    // const[que,setque]=useState(false)
      const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
       
       
        try {
          // Send a POST request to your server endpoint
          const response = await axios.post('http://localhost:5000/stud', formData);
    
          if (response.data.success) {
            setstt(true);
            alert(`Welcome, ${response.data.student.name}!`);
           
          } else {
            setstt(false);
            alert('Invalid ID or password');
          }
        } catch (error) {
          console.error('Error submitting data:', error);
          alert('Error submitting data. Please try again.');
        }
         
        } 
      
    function handleStartTest  ()  {
      console.log(formData.id);
      startTest(formData.id);
      };
  return (
    
    <div>
      <h2>Student Component</h2>
      
      <label>ID:</label>
      <input type='number' onChange={handleChange} name="id"></input>
      <label>password:</label>
      <input type='text' onChange={handleChange} name='password'></input>
      <button onClick={handleSubmit}>submit</button>
     {stt===true&&( <button onClick={handleStartTest}>Start Test</button>)}
{/* {que===true&&(<Questions></Questions>)} */}

    </div>
  );
};

export default Student;


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const Questions = () => {
//   const [questions, setQuestions] = useState([]);

//   useEffect(() => {
//     // Fetch questions from the server when the component mounts
//     fetchQuestions();
//   }, []);

//   const fetchQuestions = async () => {
//     try {
//       const response = await axios.get('http://localhost:3001/questions');
//       setQuestions(response.data);
//     } catch (error) {
//       console.error('Error fetching questions:', error);
//     }
//   };

//   return (
//     <div>
//       <h2>Questions</h2>
//       <ul>
//         {questions.map((question) => (
//           <li key={question.id}>
//             <p>{question.que}</p>
//             <ul>
//               <li>{question.o1}</li>
//               <li>{question.o2}</li>
//               <li>{question.o3}</li>
//               <li>{question.o4}</li>
//             </ul>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default Questions;
