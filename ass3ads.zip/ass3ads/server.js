const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const { computeHeadingLevel } = require('@testing-library/react');

const app = express();
const PORT = 5000;

// MySQL database configuration
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'garade',
  password: '12345',
  database: 'ads2',
});

console.log(connection);

// Connect to MySQL database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// API endpoint to handle the insertion of student data
app.post('/signst', (req, res) => {
  const { name, id, password, department } = req.body;
  const insertQuery = 'INSERT INTO Student (name, id, password, department) VALUES (?, ?, ?, ?)';

  connection.query(insertQuery, [name, id, password, department], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error creating user');
    } else {
      res.status(201).send('User created successfully');
    }
  });
});
app.post('/signadv', (req, res) => {
    const { name, id, password, department } = req.body;
    const insertQuery = 'INSERT INTO advisor (name, id, password, department) VALUES (?, ?, ?, ?)';
  
    connection.query(insertQuery, [name, id, password, department], (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Error creating user');
      } else {
        res.status(201).send('User created successfully');
      }
    });
  });

  app.post('/signins', (req, res) => {
    const { name, id, password, department } = req.body;
    const insertQuery = 'INSERT INTO instructor (name, id, password, department) VALUES (?, ?, ?, ?)';
  
    connection.query(insertQuery, [name, id, password, department], (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Error creating user');
      } else {
        res.status(201).send('User created successfully');
      }
    });
  });
  app.post('/checkLogin', (req, res) => {
    const { id, password } = req.body;
  
    // Query the database to check if the provided ID and password match any student record
    const query = 'SELECT * FROM student WHERE id = ? AND password = ?';
    connection.query(query, [id, password], (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        res.json({ success: false, message: 'Error during login' });
        return;
      }
      if (results.length > 0) {
        const foundStudent = results[0];
        res.json({ success: true, message: 'Login successful', student: foundStudent });
      } else {
        res.json({ success: false, message: 'Invalid ID or password' });
      }
    });
  });


  app.post('/instr', (req, res) => {
    const { id, password } = req.body;
    console.log(req.body)
  // alert('inside'); 
    // Query the database to check if the provided ID and password match any student record
    const query = 'SELECT * FROM instructor WHERE id = ? AND password = ?';
    connection.query(query, [id, password], (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        res.json({ success: false, message: 'Error during login' });
        return;
      }
      if (results.length > 0) {
        const foundinstructor = results[0];
        res.json({ success: true, message: 'Login successful', instructor: foundinstructor});
      } else {
        res.json({ success: false, message: 'Invalid ID or password' });
      }
    });
  });
  app.post('/adv', (req, res) => {
    const { id, password } = req.body;
    console.log(req.body)
  // alert('inside'); 
    // Query the database to check if the provided ID and password match any student record
    const query = 'SELECT * FROM advisor WHERE id = ? AND password = ?';
    connection.query(query, [id, password], (err, results) => {
      if (err) {
        console.error('Error querying database:', err);
        res.json({ success: false, message: 'Error during login' });
        return;
      }
      if (results.length > 0) {
        const foundadvisor = results[0];
        res.json({ success: true, message: 'Login successful', advisor: foundadvisor});
      } else {
        res.json({ success: false, message: 'Invalid ID or password' });
      }
    });
  });

  const bodyParser=require('body-parser')
  app.use(bodyParser.json())
  // const cors = require('cors');
  app.use(cors());
  app.get('/students', (req, res) => {
    const query = 'SELECT * FROM student';
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Error executing query:', err);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.json(result);
      }
    });
  });
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
