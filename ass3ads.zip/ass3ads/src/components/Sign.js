
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom';
import SignAdv from './SignAdv';
import SignIn from './SignIn';
import SignSt from './SignSt';
function Sign()
{
return (
    <div>
        
 <Link to='adv'><button>Advisor</button></Link>
            <Link to='in'><button>Instructor</button></Link>
            <Link to='st'><button>Student</button></Link>
            <Outlet></Outlet>
    </div>

)
}
export default Sign