
import {  Link ,Outlet} from 'react-router-dom';

function Login()
{
return (
    <div>
     <Link to='ladv'><button>Advisor</button></Link>
    <Link to='lin'><button>Instructor</button></Link>
    <Link to='lst'><button>Student</button></Link>
    <Outlet></Outlet>
    </div>
)
}
export default Login