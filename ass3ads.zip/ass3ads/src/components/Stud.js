import React, { useState } from 'react';
import axios from 'axios';

function Stud() {
  const [formData, setFormData] = useState({
    id: '',
    password: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
   
   

      // Reset the form after successful submission
    //   setFormData({
    //     name: '',
    //     id: '',
    //     password: '',
    //     department: '',
    //   });
    try {
      // Send a POST request to your server endpoint
      const response = await axios.post('http://localhost:5000/checkLogin', formData);

      if (response.data.success) {
        alert(`Welcome, ${response.data.student.name}!`);
      } else {
        alert('Invalid ID or password');
      }
    } catch (error) {
      console.error('Error submitting data:', error);
      alert('Error submitting data. Please try again.');
    }
     
    } 
  

  return (
    <div>
      <form onSubmit={handleSubmit}>
      
        <label>Student ID:</label>
        <input type='number' name="id" value={formData.id} onChange={handleChange}></input>

        <br></br>
      
        <label>Password:</label>
        <input type='password' name="password" value={formData.password} onChange={handleChange}></input>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Stud;
