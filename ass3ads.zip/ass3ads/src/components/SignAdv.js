import React, { useState } from 'react';
import axios from 'axios';

function SignAdv() {
  const [formData, setFormData] = useState({
    name: '',
    id: '',
    password: '',
    department: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData.name + formData.id + formData.password + formData.department);
    try {
      // Send a POST request to your server endpoint
      await axios.post('http://localhost:5000/signadv', formData);

      // Reset the form after successful submission
    //   setFormData({
    //     name: '',
    //     id: '',
    //     password: '',
    //     department: '',
    //   });

      alert('Data submitted successfully!');
    } catch (error) {
      console.error('Error submitting data:', error);
      alert('Error submitting data. Please try again.');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>Adviser NAME:</label>
        <input type='text' name="name" value={formData.name} onChange={handleChange}></input>
        <br></br>
        <label>ID:</label>
        <input type='number' name="id" value={formData.id} onChange={handleChange}></input>

        <br></br>
        <label>Department Name:</label>
        <input type='text' name="department" value={formData.department} onChange={handleChange}></input>

        <br></br>
        <label>Password:</label>
        <input type='password' name="password" value={formData.password} onChange={handleChange}></input>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default SignAdv;
