import React, { useState } from 'react';
import axios from 'axios';
import { Link, Outlet } from 'react-router-dom';
import './Instr.css'
function Instr() {
  const [formData, setFormData] = useState({
    id: '',
    password: '',
  });
  const [stu,setstu]=useState(0)

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        // Send a POST request to your server endpoint
    
        console.log(formData.id+formData.password)
        const response = await axios.post('http://localhost:5000/instr', formData);
        if (response.data.success) {
            alert(`Welcome, ${response.data.instructor.name}!`);
            setstu(1);
          } else {
            alert('Invalid ID or password');
      }
     } catch (error) {
        console.error('Error submitting data:', error);
        alert('Error submitting data. Please try again.');
      }
    } 
  

  return (
    <div>
      <form onSubmit={handleSubmit}>
      
        <label>Instructor ID:</label>
        <input type='number' name="id" value={formData.id} onChange={handleChange}></input>

        <br></br>
      
        <label>Password:</label>
        <input type='password' name="password" value={formData.password} onChange={handleChange}></input>

        <button type="submit">Submit</button>
        {stu===1&&(<div><Link to='dst'><button>student list</button></Link><Outlet></Outlet></div>)}
      </form>
    </div>
  );
}

export default Instr;
