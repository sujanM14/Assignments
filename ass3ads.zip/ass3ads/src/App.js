import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom';
import Pogin from './components/Pogin';
import './App.css'
import Sign from './components/Sign';
import SignAdv from './components/SignAdv';
import SignIn from './components/SignIn';
import SignSt from './components/SignSt';
import Stud from './components/Stud';
import Adv from './components/Adv'
import Instr from './components/Instr'
import Slist from './components/Slist';
import Ilist from './components/Ilist';

function App() {
  const [vis,setvis]=useState(1)
  function LShandler()
  {
    if(vis===1)
   { setvis(0);}
   else{
    setvis(1);
   }

  }
  return (
    <div className="App">
   { vis===0 &&<button onClick={LShandler}>home</button>}
    <div >
    {vis===1 &&(<h1>Welcome to Saraswati Institute of Technology</h1>)}

    
   
    
      </div>
      
      <Router>
      <Link to="/Login">{vis===1 &&(<button onClick={LShandler}>Login</button>)}</Link>
      <Link to="/Sign">{vis===1 &&(<button onClick={LShandler}>sign</button>)}</Link>
        <Routes>
        {vis===0&&(  <Route path="/Login" element={<Pogin />} >
            <Route path='ladv' element={<Adv />} >
              <Route path='dst' element={<Slist/>}/>
            </Route>
            <Route path='lin' element={<Instr />} >
              <Route path='dst' element={<Slist/>}/>
            </Route>
            <Route path='lst' element={<Stud />} >
              <Route path='din' element={<Ilist/>}/>
            </Route>
          </Route>)}
          {vis===0&&( <Route path="/Sign" element={<Sign />} >
           
            <Route path='adv' element={<SignAdv />} />
            <Route path='in' element={<SignIn />} />
            <Route path='st' element={<SignSt />} />
          </Route>)}
        </Routes>
      </Router>
  
    </div>
  );
}

export default App;
